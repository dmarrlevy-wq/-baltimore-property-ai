#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if [ ! -x ".venv/bin/python" ]; then
  python3 -m venv .venv
fi
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
( sleep 2; open http://localhost:8501 2>/dev/null || xdg-open http://localhost:8501 2>/dev/null || true ) &
streamlit run app.py
