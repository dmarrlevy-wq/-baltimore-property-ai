#!/usr/bin/env bash
"$(dirname "$0")/start.sh"
