# Public sources used

- Baltimore real property ArcGIS FeatureServer:
  https://geodata.baltimorecity.gov/egis/rest/services/CityView/Realproperty_OB/FeatureServer/0
- Baltimore 2026 tax sale ArcGIS FeatureServer:
  https://egis.baltimorecity.gov/egis/rest/services/Housing/Tax_Sale_2026/FeatureServer/0
- Baltimore DHCD open datasets:
  https://baltegis.baltimorecity.gov/mapping/rest/services/Housing/DHCD_Open_Baltimore_Datasets/FeatureServer
- Baltimore 311 open traffic cases:
  https://gisdata.baltimorecity.gov/egis/rest/services/311/311_Open_Traffic_cases/FeatureServer/0
