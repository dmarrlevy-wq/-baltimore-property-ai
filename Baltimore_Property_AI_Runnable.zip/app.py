
import re, math
from datetime import datetime
from urllib.parse import quote

import pandas as pd
import requests
import streamlit as st

try:
    import folium
    from streamlit_folium import st_folium
    HAS_MAP = True
except Exception:
    HAS_MAP = False

st.set_page_config(page_title="Baltimore Property AI", page_icon="🏠", layout="wide")

PROPERTY_URL = "https://geodata.baltimorecity.gov/egis/rest/services/CityView/Realproperty_OB/FeatureServer/0"
TAXSALE_URL = "https://egis.baltimorecity.gov/egis/rest/services/Housing/Tax_Sale_2026/FeatureServer/0"
DHCD_URL = "https://baltegis.baltimorecity.gov/mapping/rest/services/Housing/DHCD_Open_Baltimore_Datasets/FeatureServer"
VACANCY_URL = DHCD_URL + "/1"
FORECLOSURE_URL = DHCD_URL + "/11"
DEFAULT_311_URL = "https://gisdata.baltimorecity.gov/egis/rest/services/311/311_Open_Traffic_cases/FeatureServer/0"

SESSION = requests.Session()
SESSION.headers.update({"User-Agent": "BaltimorePropertyAI/2.0 (public-data research tool)"})

def arcgis_json(url, params=None, timeout=30):
    p = {"f": "json"}
    if params:
        p.update(params)
    r = SESSION.get(url, params=p, timeout=timeout)
    r.raise_for_status()
    data = r.json()
    if "error" in data:
        raise RuntimeError(data["error"].get("message", "ArcGIS error"))
    return data

@st.cache_data(ttl=900, show_spinner=False)
def layer_meta(url):
    return arcgis_json(url)

def arcgis_query(url, where="1=1", out_fields="*", result_record_count=1000,
                 return_geometry=False, order_by=None, out_sr=4326):
    params = {
        "where": where,
        "outFields": out_fields,
        "returnGeometry": "true" if return_geometry else "false",
        "resultRecordCount": min(result_record_count, 2000),
        "f": "json",
    }
    if return_geometry:
        params["outSR"] = out_sr
    if order_by:
        params["orderByFields"] = order_by
    data = arcgis_json(url, params)
    rows = []
    for f in data.get("features", []):
        a = dict(f.get("attributes", {}))
        if return_geometry:
            a["_geometry"] = f.get("geometry")
        rows.append(a)
    return pd.DataFrame(rows)

def arcgis_paginated(url, where="1=1", out_fields="*", limit=1000,
                     return_geometry=False, order_by=None, out_sr=4326):
    meta = layer_meta(url)
    max_count = int(meta.get("maxRecordCount", 1000) or 1000)
    limit = min(limit, 10000)
    ids = None
    try:
        ids_data = arcgis_json(url, {
            "where": where, "returnIdsOnly": "true", "f": "json"
        })
        ids = ids_data.get("objectIds")
    except Exception:
        ids = None

    if ids:
        ids = sorted(ids)[:limit]
        chunks = [ids[i:i+max_count] for i in range(0, len(ids), max_count)]
        frames = []
        for chunk in chunks:
            params = {
                "objectIds": ",".join(map(str, chunk)),
                "outFields": out_fields,
                "returnGeometry": "true" if return_geometry else "false",
                "f": "json",
            }
            if return_geometry:
                params["outSR"] = out_sr
            data = arcgis_json(url, params)
            for f in data.get("features", []):
                a = dict(f.get("attributes", {}))
                if return_geometry:
                    a["_geometry"] = f.get("geometry")
                frames.append(a)
        return pd.DataFrame(frames)

    frames, offset = [], 0
    while len(frames) < limit:
        params = {
            "where": where,
            "outFields": out_fields,
            "returnGeometry": "true" if return_geometry else "false",
            "resultOffset": offset,
            "resultRecordCount": min(max_count, limit-len(frames)),
            "f": "json",
        }
        if return_geometry:
            params["outSR"] = out_sr
        if order_by:
            params["orderByFields"] = order_by
        data = arcgis_json(url, params)
        feats = data.get("features", [])
        for f in feats:
            a = dict(f.get("attributes", {}))
            if return_geometry:
                a["_geometry"] = f.get("geometry")
            frames.append(a)
        if len(feats) < min(max_count, limit-len(frames)+len(feats)):
            break
        offset += len(feats)
    return pd.DataFrame(frames[:limit])

def pick_field(df, names):
    cols = {str(c).upper(): c for c in df.columns}
    for n in names:
        if n.upper() in cols:
            return cols[n.upper()]
    return None

def norm_addr(x):
    if pd.isna(x): return ""
    x = str(x).upper()
    x = re.sub(r"[^A-Z0-9 ]", " ", x)
    return re.sub(r"\s+", " ", x).strip()

def num(x):
    try:
        if pd.isna(x): return 0.0
        return float(str(x).replace("$","").replace(",",""))
    except Exception:
        return 0.0

def clean_bool(x):
    return str(x).strip().upper() in {"Y","YES","TRUE","1","T"}

def score_row(r):
    score, reasons = 0.0, []
    lien = num(r.get("LIEN_AMOUNT", 0))
    if lien > 0:
        pts = min(24, 8 + math.log10(max(lien,1))*5)
        score += pts; reasons.append(f"Tax-sale lien ${lien:,.0f}")
    if r.get("TAX_SALE", False):
        score += 14; reasons.append("2026 tax-sale record")
    if r.get("VACANT", False):
        score += 18; reasons.append("Open vacant-building signal")
    if r.get("FORECLOSURE", False):
        score += 18; reasons.append("Foreclosure filing signal")
    complaints = int(num(r.get("311_COUNT",0)))
    if complaints:
        pts = min(12, 2 + complaints * .75)
        score += pts; reasons.append(f"{complaints} matched 311 record(s)")
    if r.get("ABSENTEE", False):
        score += 7; reasons.append("Mailing address differs from property address")
    years = num(r.get("OWNERSHIP_YEARS",0))
    if years >= 15:
        score += 5; reasons.append(f"{years:.0f} years since recorded sale")
    elif years >= 10:
        score += 3; reasons.append(f"{years:.0f} years since recorded sale")
    year = num(r.get("YEAR_BUILD",0))
    if 0 < year < 1950:
        score += 4; reasons.append("Older building")
    value = num(r.get("ASSESSED_TOTAL",0))
    if value > 0 and lien > 0:
        ratio = lien / value
        if ratio >= .10:
            score += 4; reasons.append("Lien is material relative to assessed value")
        elif ratio >= .05:
            score += 2; reasons.append("Lien is notable relative to assessed value")
    return round(min(100, score),1), reasons

def standardize_tax(tax):
    if tax.empty: return tax
    b = pick_field(tax, ["BLOCKLOT","BLOCK_LOT","BLOCKLOTNO","BLOCK"])
    addr = pick_field(tax, ["FULLADDR","ADDRESS","SITEADDRESS","SITUS","LOCATION","LOC_NAME"])
    owner = pick_field(tax, ["OWNER_1","OWNER","OWNERNAME","NAME"])
    lien = pick_field(tax, ["LIEN_AMOUNT","LIENAMOUNT","LIEN","AMOUNT"])
    if b: tax["BLOCKLOT"] = tax[b].astype(str)
    if addr: tax["ADDRESS"] = tax[addr].fillna("")
    if owner: tax["OWNER"] = tax[owner].fillna("")
    tax["LIEN_AMOUNT"] = pd.to_numeric(tax[lien], errors="coerce").fillna(0) if lien else 0
    tax["TAX_SALE"] = True
    return tax

def standardize_property(props):
    if props.empty: return props
    b = pick_field(props, ["BLOCKLOT","BLOCK_LOT","BLOCKLOTNO","BLOCK"])
    if b: props["BLOCKLOT"] = props[b].astype(str)
    mapping = {
        "OWNER_1":"OWNER_PROPERTY","OWNER":"OWNER_PROPERTY",
        "MAILTOADD":"MAILING_ADDRESS","MAIL_ADDR":"MAILING_ADDRESS",
        "FULLADDR":"PROPERTY_ADDRESS","ADDRESS":"PROPERTY_ADDRESS",
        "NEIGHBOR":"NEIGHBORHOOD","BFCVLAND":"ASSESSED_LAND",
        "BFCVIMPR":"ASSESSED_IMPROVEMENTS","FULLCASH":"ASSESSED_TOTAL",
        "SALEDATE":"SALE_DATE","SALEPRIC":"SALE_PRICE","YEAR_BUILD":"YEAR_BUILD",
        "STRUCTAREA":"STRUCTURE_SQFT","ZONECODE":"ZONING","VACIND":"VACANT_INDICATOR",
        "PIN":"PIN","SDATCODE":"LAND_USE_CODE"
    }
    for src, dst in mapping.items():
        if src in props.columns and dst not in props.columns:
            props[dst] = props[src]
    for c in ["ASSESSED_LAND","ASSESSED_IMPROVEMENTS","ASSESSED_TOTAL","SALE_PRICE","YEAR_BUILD","STRUCTURE_SQFT"]:
        if c in props: props[c] = pd.to_numeric(props[c], errors="coerce").fillna(0)
    return props

def load_candidates(limit):
    tax = standardize_tax(arcgis_paginated(TAXSALE_URL, limit=limit, return_geometry=True))
    if tax.empty: return tax, pd.DataFrame()
    props = standardize_property(arcgis_paginated(PROPERTY_URL, limit=10000, return_geometry=False))
    # Match tax-sale candidates to the property service by block/lot when possible.
    if "BLOCKLOT" in tax and "BLOCKLOT" in props:
        keep = [c for c in ["BLOCKLOT","PROPERTY_ADDRESS","OWNER_PROPERTY","MAILING_ADDRESS","NEIGHBORHOOD",
            "ASSESSED_LAND","ASSESSED_IMPROVEMENTS","ASSESSED_TOTAL","SALE_DATE","SALE_PRICE","YEAR_BUILD",
            "STRUCTURE_SQFT","ZONING","VACANT_INDICATOR","PIN","LAND_USE_CODE"] if c in props]
        if keep:
            tax = tax.merge(props[keep].drop_duplicates("BLOCKLOT"), on="BLOCKLOT", how="left")
    return tax, props

def load_signals(df):
    out = df.copy()
    if "BLOCKLOT" not in out: out["BLOCKLOT"] = ""
    try:
        v = standardize_property(arcgis_paginated(VACANCY_URL, limit=10000))
        vb = pick_field(v, ["BLOCKLOT","BLOCK_LOT","BLOCKLOTNO","BLOCK"])
        if vb:
            v["BLOCKLOT"] = v[vb].astype(str)
            out = out.merge(v[["BLOCKLOT"]].drop_duplicates(), on="BLOCKLOT", how="left", indicator="_vacmerge")
            out["VACANT"] = out["_vacmerge"].eq("both")
            out.drop(columns=["_vacmerge"], inplace=True)
        else: out["VACANT"] = False
    except Exception:
        out["VACANT"] = False
    try:
        f = arcgis_paginated(FORECLOSURE_URL, limit=10000)
        fb = pick_field(f, ["BLOCKLOT","BLOCK_LOT","BLOCKLOTNO","BLOCK"])
        if fb:
            f["BLOCKLOT"] = f[fb].astype(str)
            out = out.merge(f[["BLOCKLOT"]].drop_duplicates(), on="BLOCKLOT", how="left", indicator="_fcmerge")
            out["FORECLOSURE"] = out["_fcmerge"].eq("both")
            out.drop(columns=["_fcmerge"], inplace=True)
        else: out["FORECLOSURE"] = False
    except Exception:
        out["FORECLOSURE"] = False

    sale = pd.to_datetime(out.get("SALE_DATE"), errors="coerce")
    out["OWNERSHIP_YEARS"] = ((pd.Timestamp.today() - sale).dt.days / 365.25).clip(lower=0)
    pa = out.get("PROPERTY_ADDRESS", out.get("ADDRESS", pd.Series("", index=out.index))).map(norm_addr)
    ma = out.get("MAILING_ADDRESS", pd.Series("", index=out.index)).map(norm_addr)
    out["ABSENTEE"] = (pa != "") & (ma != "") & ~pa.eq(ma)
    return out

def query_311(address, service_url):
    if not address: return pd.DataFrame()
    meta = layer_meta(service_url)
    fields = [f["name"] for f in meta.get("fields",[])]
    candidates = [f for f in fields if any(k in f.upper() for k in ["ADDRESS","LOCATION","STREET"])]
    if not candidates: return pd.DataFrame()
    safe = address.replace("'","''")
    where = " OR ".join([f"UPPER({f}) LIKE UPPER('%{safe}%')" for f in candidates[:5]])
    return arcgis_query(service_url, where=where, result_record_count=1000)

@st.cache_data(ttl=900, show_spinner=False)
def load_all(limit):
    data, props = load_candidates(limit)
    return load_signals(data), props

st.title("🏠 Baltimore Property AI")
st.caption("Baltimore City public-record intelligence • explainable ranking • due-diligence workflow")

with st.sidebar:
    st.header("Lead Filters")
    limit = st.slider("Tax-sale records to load", 100, 2000, 1000, 100)
    min_score = st.slider("Minimum signal score", 0, 100, 0)
    min_lien = st.number_input("Minimum tax-sale lien ($)", 0.0, 1000000.0, 0.0, 500.0)
    vacant_only = st.checkbox("Vacant-building signal only")
    foreclosure_only = st.checkbox("Foreclosure signal only")
    absentee_only = st.checkbox("Absentee-owner indicator only")
    st.divider()
    service_311 = st.text_input("311 FeatureServer URL", DEFAULT_311_URL)
    if st.button("🔄 Refresh public data"):
        st.cache_data.clear()
        st.rerun()

try:
    data, props = load_all(limit)
except Exception as e:
    st.error(f"Public data source error: {e}")
    st.info("The app is designed to fail visibly rather than invent records. Try Refresh public data.")
    st.stop()

if data.empty:
    st.warning("No tax-sale records were returned by the current public service.")
    st.stop()

data["SCORE"], data["WHY"] = zip(*data.apply(score_row, axis=1))
data["ADDRESS_DISPLAY"] = data.get("PROPERTY_ADDRESS", data.get("ADDRESS", "")).fillna("")
data["OWNER_DISPLAY"] = data.get("OWNER_PROPERTY", data.get("OWNER", "")).fillna("")
data["ASSESSED_TOTAL"] = pd.to_numeric(data.get("ASSESSED_TOTAL", 0), errors="coerce").fillna(0)
data["LIEN_AMOUNT"] = pd.to_numeric(data.get("LIEN_AMOUNT", 0), errors="coerce").fillna(0)

search = st.text_input("🔎 Search address, owner, block/lot or neighborhood", "")
filtered = data[
    (data.SCORE >= min_score) & (data.LIEN_AMOUNT >= min_lien) &
    ((~vacant_only) | data.VACANT) &
    ((~foreclosure_only) | data.FORECLOSURE) &
    ((~absentee_only) | data.ABSENTEE)
].copy()

if search.strip():
    q = norm_addr(search)
    hay = (
        filtered["ADDRESS_DISPLAY"].map(norm_addr) + " | " +
        filtered["OWNER_DISPLAY"].map(norm_addr) + " | " +
        filtered.get("BLOCKLOT", pd.Series("", index=filtered.index)).astype(str).map(norm_addr) + " | " +
        filtered.get("NEIGHBORHOOD", pd.Series("", index=filtered.index)).astype(str).map(norm_addr)
    )
    filtered = filtered[hay.str.contains(q, regex=False, na=False)]

filtered = filtered.sort_values(["SCORE","LIEN_AMOUNT"], ascending=[False,False]).reset_index(drop=True)

c1,c2,c3,c4 = st.columns(4)
c1.metric("Candidates", len(data))
c2.metric("Showing", len(filtered))
c3.metric("Vacant signals", int(data.VACANT.sum()))
c4.metric("Foreclosure signals", int(data.FORECLOSURE.sum()))

tab1, tab2, tab3, tab4, tab5 = st.tabs(["📊 Ranked Leads","🗺️ Map","🔍 Property Intelligence","🧮 Deal Analyzer","🩺 Data Health"])

with tab1:
    show_cols = [c for c in ["SCORE","ADDRESS_DISPLAY","OWNER_DISPLAY","LIEN_AMOUNT","VACANT","FORECLOSURE","ABSENTEE",
        "OWNERSHIP_YEARS","ASSESSED_TOTAL","YEAR_BUILD","NEIGHBORHOOD"] if c in filtered]
    display = filtered[show_cols].copy()
    display.rename(columns={"SCORE":"Score","ADDRESS_DISPLAY":"Address","OWNER_DISPLAY":"Owner",
        "LIEN_AMOUNT":"Tax-sale lien","VACANT":"Vacant","FORECLOSURE":"Foreclosure","ABSENTEE":"Absentee",
        "OWNERSHIP_YEARS":"Ownership years","ASSESSED_TOTAL":"Assessed total","YEAR_BUILD":"Year built",
        "NEIGHBORHOOD":"Neighborhood"}, inplace=True)
    st.dataframe(display, use_container_width=True, height=520)
    st.download_button("⬇️ Export ranked CSV", display.to_csv(index=False).encode(), "baltimore_property_ai_leads.csv", "text/csv")

with tab2:
    if not HAS_MAP:
        st.info("Map support is optional. Install folium + streamlit-folium (included in requirements.txt).")
    else:
        m = folium.Map(location=[39.2904,-76.6122], zoom_start=11, tiles="CartoDB positron")
        count = 0
        for _, r in filtered.head(500).iterrows():
            g = r.get("_geometry")
            if isinstance(g, dict):
                x, y = g.get("x"), g.get("y")
                if x is not None and y is not None and -180 <= x <= 180 and -90 <= y <= 90:
                    folium.CircleMarker([y,x], radius=5, tooltip=f"{r.get('ADDRESS_DISPLAY','')} • {r.SCORE:.0f}").add_to(m)
                    count += 1
        st_folium(m, width=None, height=600)
        st.caption(f"Mapped {count} records with geographic point coordinates returned as latitude/longitude.")

with tab3:
    if filtered.empty:
        st.info("No properties match the current filters.")
    else:
        choices = [f"{i+1}. {a}" for i,a in enumerate(filtered["ADDRESS_DISPLAY"].fillna("").tolist())]
        pick = st.selectbox("Select a property", choices)
        idx = choices.index(pick)
        r = filtered.iloc[idx]
        a,b,c = st.columns(3)
        a.metric("Signal score", f"{r.SCORE:.0f}/100")
        b.metric("Tax-sale lien", f"${r.LIEN_AMOUNT:,.0f}")
        c.metric("Assessed total", f"${r.ASSESSED_TOTAL:,.0f}")
        st.subheader(r.get("ADDRESS_DISPLAY","") or "Property")
        fields = [
            ("Owner", "OWNER_DISPLAY"), ("Mailing address","MAILING_ADDRESS"), ("Block/Lot","BLOCKLOT"),
            ("Neighborhood","NEIGHBORHOOD"), ("Year built","YEAR_BUILD"), ("Structure area","STRUCTURE_SQFT"),
            ("Zoning","ZONING"), ("Last sale","SALE_DATE"), ("Last sale price","SALE_PRICE"),
            ("Ownership duration","OWNERSHIP_YEARS"), ("Vacant-building signal","VACANT"),
            ("Foreclosure signal","FORECLOSURE"), ("Absentee indicator","ABSENTEE")
        ]
        for label,key in fields:
            val = r.get(key,"")
            if key in {"SALE_PRICE"}: val = f"${num(val):,.0f}"
            elif key == "OWNERSHIP_YEARS": val = f"{num(val):.1f} years"
            elif key in {"VACANT","FORECLOSURE","ABSENTEE"}: val = "Yes" if bool(val) else "No"
            st.write(f"**{label}:** {val}")
        st.subheader("Why it ranked here")
        for reason in r.get("WHY", []): st.write("• " + reason)
        st.caption("The score measures documented public-record signals. It does not predict seller intent, legal outcome, or investment profitability.")
        if st.button("🔎 Query 311 for this address"):
            with st.spinner("Querying Baltimore 311..."):
                try:
                    results = query_311(r.get("ADDRESS_DISPLAY",""), service_311)
                    st.metric("Matched 311 records", len(results))
                    if not results.empty: st.dataframe(results, use_container_width=True)
                except Exception as e:
                    st.error(f"311 query failed: {e}")

with tab4:
    st.subheader("Deal Analyzer")
    st.caption("User-entered underwriting tool; values are assumptions, not appraisals.")
    x1,x2 = st.columns(2)
    with x1:
        arv = st.number_input("Estimated ARV ($)", min_value=0.0, value=250000.0, step=5000.0)
        repairs = st.number_input("Repairs ($)", min_value=0.0, value=50000.0, step=5000.0)
        closing = st.number_input("Closing / selling costs ($)", min_value=0.0, value=15000.0, step=1000.0)
    with x2:
        profit = st.number_input("Target profit ($)", min_value=0.0, value=30000.0, step=5000.0)
        fixed = st.number_input("Other fixed / assignment costs ($)", min_value=0.0, value=5000.0, step=500.0)
        purchase = st.number_input("Proposed purchase price ($)", min_value=0.0, value=100000.0, step=5000.0)
    mao = max(0, arv - repairs - closing - profit - fixed)
    spread = arv - repairs - closing - fixed - purchase
    d1,d2,d3 = st.columns(3)
    d1.metric("Estimated MAO", f"${mao:,.0f}")
    d2.metric("Gross spread", f"${spread:,.0f}")
    d3.metric("Offer vs. MAO", f"${purchase-mao:,.0f}")
    if purchase <= mao and purchase > 0: st.success("Entered purchase price is at or below the user-defined MAO.")
    elif purchase > mao: st.warning("Entered purchase price is above the user-defined MAO.")

with tab5:
    st.subheader("Public-source health")
    sources = {
        "Baltimore real property": PROPERTY_URL,
        "Baltimore 2026 tax sale": TAXSALE_URL,
        "DHCD vacant-building notices": VACANCY_URL,
        "DHCD foreclosure filings": FORECLOSURE_URL,
        "Baltimore 311": service_311,
    }
    for name,url in sources.items():
        try:
            meta = layer_meta(url)
            st.success(f"✓ {name} — reachable ({meta.get('name','FeatureServer')})")
        except Exception as e:
            st.error(f"✕ {name} — {e}")

st.divider()
st.caption("Sources are public Baltimore City ArcGIS services. Verify records independently before making legal, financial, or acquisition decisions.")
