# Baltimore Property AI — Runnable App

This is a runnable Streamlit web application for Baltimore City public-record property intelligence.

## What it does
- Pulls 2026 Baltimore tax-sale properties from the City's public ArcGIS service.
- Enriches candidates with Baltimore real-property information.
- Matches open vacant-building notices and foreclosure-filing signals.
- Computes an explainable 0–100 public-record signal score.
- Ranks leads and supports address/owner/block-lot search.
- Provides a property intelligence profile.
- Queries the public Baltimore 311 FeatureServer for a selected property.
- Includes an interactive map when coordinates are returned.
- Includes a deal analyzer with MAO/spread calculations.
- Includes a public-source health panel.
- Exports the ranked list as CSV.

## Fastest way to run on a computer

### Windows
Double-click `START_BALTIMORE_PROPERTY_AI.bat`.

### macOS / Linux
Double-click `START_BALTIMORE_PROPERTY_AI.command` on macOS (you may need to allow it in System Settings), or run:
```bash
bash start.sh
```

The launcher creates a virtual environment, installs the requirements, starts Streamlit, and opens the app in your browser.

## Manual
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

## Deployment
The project can be deployed to Streamlit Community Cloud or any Docker-capable host. `Dockerfile` is included.

## Important data note
The app uses public Baltimore City ArcGIS services. It does not scrape Maryland SDAT. The score is an explainable signal-ranking system, not a prediction of seller intent, legal outcome, property condition, or profitability. Always verify records and conduct proper due diligence.
